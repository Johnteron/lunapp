$(document).ready(function(){
$("#kero").click(function(){
    alert("Hello Word");
});
});